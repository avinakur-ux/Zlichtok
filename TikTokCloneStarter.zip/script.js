document.querySelectorAll('video').forEach(v=>{v.muted=true;v.loop=true;});
const io=new IntersectionObserver(es=>es.forEach(e=>{const v=e.target;if(e.isIntersecting){v.play()}else{v.pause()}}),{threshold:.7});
document.querySelectorAll('video').forEach(v=>io.observe(v));